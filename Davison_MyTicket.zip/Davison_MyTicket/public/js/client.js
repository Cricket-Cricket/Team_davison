'use strict';
(function (api) {
    var url = '/api/ticket/';

    function extractIDFromResponse(xhr) {
        var location = xhr.getResponseHeader('location');
        var result = +location.slice(url.length);
        return result;
    }
    api.create = function createTicket(title, callback) {
        var xhr = new XMLHttpRequest();
        var todo = {
            title: title,
            complete: false
        };
        xhr.open('POST', url);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onload = function () {
            if (xhr.status === 201) {
                ticket.id = extractIDFromResponse(xhr);
            }
            return callback(null, xhr, ticket);
        };
        xhr.send(JSON.stringify(ticket));
    };
    api.update = function createTicket(ticket, callback) {
        var xhr = new XMLHttpRequest();
        xhr.open('PUT', url);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onload = function () {
            if (xhr.status === 200) {
                console.log('200');
            }
            return callback(null, xhr, ticket);
        };
        xhr.send(JSON.stringify(ticket));
    };
})(this.ticketAPI = {});
